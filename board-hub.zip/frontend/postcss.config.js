export default {
  plugins: {
    autoprefixer: {},
    tailwindcss: {},
  },
};
